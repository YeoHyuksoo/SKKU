let no = document.getElementById("no");
let yes = document.getElementById("yes");
no.addEventListener("mouseenter", accessNO);
yes.addEventListener("mouseenter", accessYES);

function accessNO(){

  var top = getRandomInt(0, 99);
  var left = getRandomInt(0, 99);
  no.style.left = left + "%";
  no.style.top = top + "%";
}

function accessYES(){
  yes.style.backgroundColor = "Purple";
  //document.getElementById("changeimg").src = "./images/answer.jpg";
}

function clickYES(){
  document.getElementById("changeimg").src = "./images/answer.jpg";
}

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}
