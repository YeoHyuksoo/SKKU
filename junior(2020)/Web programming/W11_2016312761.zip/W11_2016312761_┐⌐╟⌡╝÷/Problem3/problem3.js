let imageInput, imageInput2, canvas, ctx;
let img, img2;

function generateMeme(){
  let upperText = document.getElementById("upper-text").value;
  let lowerText = document.getElementById("lower-text").value;

  let fontSize = canvas.width / 12;
  ctx.font = fontSize + 'px Impact';
  ctx.fillStyle = 'white';
  ctx.lineWidth = fontSize / 12;
  ctx.textAlign = 'center';

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.drawImage(img, 50, 50, 300, 300);
  ctx.fillText(upperText, canvas.width*0.7, canvas.height*0.2, canvas.width/2);

  ctx.drawImage(img2, 50, 400, 300, 300);
  ctx.fillText(lowerText, canvas.width*0.7, canvas.height*0.7, canvas.width/2);
}

function init(){
  imageInput = document.getElementById("image-input");
  imageInput2 = document.getElementById("image-input2");
  canvas = document.getElementById("meme-canvas");

  ctx = canvas.getContext('2d');

  canvas.width = canvas.height = 800;

  imageInput.addEventListener("change", function(){
    let reader = new FileReader();
    reader.onload = function(){
      img = new Image;
      img.onload = function(){
        ctx.drawImage(img, 50, 50, 300, 300);
      }
      img.src = reader.result;

//generateMeme(img, upperText.value, lowerText.value);
    };
    reader.readAsDataURL(imageInput.files[0]);
  });

  imageInput2.addEventListener("change", function(){
    let reader2 = new FileReader();
    reader2.onload = function(){
      img2 = new Image;
      img2.onload = function(){
        ctx.drawImage(img2, 50, 400, 300, 300);
      }
      img2.src = reader2.result;

//generateMeme(img, upperText.value, lowerText.value);
    };
    reader2.readAsDataURL(imageInput2.files[0]);
  });
}

init();
