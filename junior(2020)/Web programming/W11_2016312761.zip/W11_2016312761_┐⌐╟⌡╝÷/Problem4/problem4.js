let canvas, ctx, changeBtn;
var mover=0;

function init(){

  canvas = document.getElementById("canvas");
  changeBtn = document.getElementById("skillbtn");

  leftcanvas = document.getElementById("leftcanvas");
  rightcanvas = document.getElementById("rightcanvas");

  ctx = canvas.getContext('2d');

  leftctx = leftcanvas.getContext('2d');
  rightctx = rightcanvas.getContext('2d');

  canvas.width = 150;
  canvas.height = 128;

  leftcanvas.width = 400;
  leftcanvas.height = 128;
  rightcanvas.width = 400;
  rightcanvas.height = 128;

  var img = new Image();   // Create new img element
  img.addEventListener('load', function() {
    // execute drawImage statements here
    ctx.drawImage(img, mover, 0, 150, 128, 0, 0, canvas.width, canvas.height);
  }, false);
  img.src = './images/luffy.png'; // Set source path

  var leftimg = new Image();
  leftimg.src = './images/lufface2.png';
  var rightimg = new Image();
  rightimg.src = './images/lufface.png';

  changeBtn.addEventListener("click", function(){
    mover=0;
    sidemover=0;
    change();
    function change(){
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, mover, 0, 150, 128, 0, 0, canvas.width, canvas.height);

      leftctx.clearRect(0, 0, leftcanvas.width, leftcanvas.height);
      leftctx.drawImage(leftimg, 0, sidemover*-1, 400, 128, 0, 0, leftcanvas.width, leftcanvas.height);
      rightctx.clearRect(0, 0, rightcanvas.width, rightcanvas.height);
      rightctx.drawImage(rightimg, 0, sidemover*-1, 400, 128, 0, 0, rightcanvas.width, rightcanvas.height);

      mover+=150;
      sidemover+=20;
      animate = setTimeout(function(){change();}, 100);
    }

  });
}

init();
