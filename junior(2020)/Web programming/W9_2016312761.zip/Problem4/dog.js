function validate() {
  if(document.getElementById("name").value == ""){
    document.getElementById("name").style.backgroundColor = "Red";
  }
  if(document.getElementById("email").value == ""){
    document.getElementById("email").style.backgroundColor = "Red";
  }
  if(document.getElementById("zip").value == ""){
    document.getElementById("zip").style.backgroundColor = "Red";
  }
  if(document.getElementById("addr").value == ""){
    document.getElementById("addr").style.backgroundColor = "Red";
  }
  if(document.getElementById("tel").value == ""){
    document.getElementById("tel").style.backgroundColor = "Red";
  }
  if(document.getElementById("pw").value == ""){
    document.getElementById("pw").style.backgroundColor = "Red";
  }
  if(document.getElementById("ta").value == ""){
    document.getElementById("ta").style.backgroundColor = "Red";
  }
}
