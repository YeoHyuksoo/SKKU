function myFunction() {
  alert("Welcome to Web Programming Course 2020");
}
