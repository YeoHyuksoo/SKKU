$(document).ready(function(){
  $("#changebtn").click(function(){
    $("span").text($("#color").val());

  });
});
