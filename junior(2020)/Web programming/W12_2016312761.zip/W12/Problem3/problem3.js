$(document).ready(function(){
  $("#datepicker").datepicker();
  $("#name").focus(function(){
    $(this).css("background-color", "gray");
  });
  $("#name").blur(function(){
    $(this).css("background-color", "#ffffff");
  });
});
