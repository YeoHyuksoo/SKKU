$(document).ready(function(){
  $("#changecolor").click(function(){
    $(".box").toggleClass("red");
  });
  $("#changeshape").click(function(){
    $(".box").toggleClass("round");
  });
  $("#addbox").click(function(){
    var newdiv = '<div class="box"></div>';
    $(".boxes").append(newdiv);
  });
  $("#removebox").click(function(){
    $(".box").remove();
  });
});
