function validate() {

  var invalid = 0;
  document.getElementById("name").style.backgroundColor = "#fff";
  document.getElementById("email").style.backgroundColor = "#fff";
  document.getElementById("zip").style.backgroundColor = "#fff";
  document.getElementById("email2").style.backgroundColor = "#fff";
  document.getElementById("tel").style.backgroundColor = "#fff";
  document.getElementById("dept").style.backgroundColor = "#fff";
  document.getElementById("birth").style.backgroundColor = "#fff";
  document.getElementById("pw").style.backgroundColor = "#fff";
  document.getElementById("pw2").style.backgroundColor = "#fff";
  document.getElementById("ta").style.backgroundColor = "#fff";

  if(document.getElementById("name").value == ""){
    document.getElementById("name").style.backgroundColor = "Red";
    invalid = 1;
  }

  if(document.getElementById("email").value == ""){
    document.getElementById("email").style.backgroundColor = "Red";
    invalid = 1;
  }
  else{
    let emailID = document.getElementById("email").value.split("@")[0];
    let domain = document.getElementById("email").value.split("@")[1];
    if(!domain || !emailID){
      document.getElementById("email").style.backgroundColor = "Red";
      invalid = 1;
    }
    else{
      for(var i=0;i<emailID.length;i++){
        if((emailID[i]>='0' && emailID[i]<='9') || (emailID[i]>='A' && emailID[i]<='Z') || (emailID[i]>='a' && emailID[i]<='z')){
          continue;
        }
        document.getElementById("email").style.backgroundColor = "Red";
        invalid = 1;
      }
      if(domain.indexOf('.')!=-1){
        let first = domain.split('.')[0];
        let second = domain.split('.')[1];
        if(!first || !second){
          document.getElementById("email").style.backgroundColor = "Red";
          invalid = 1;
        }
        else{
          for(var i=0;i<first.length;i++){
            if((first[i]>='0' && first[i]<='9') || (first[i]>='A' && first[i]<='Z') || (first[i]>='a' && first[i]<='z')){
              continue;
            }
            document.getElementById("email").style.backgroundColor = "Red";
            invalid = 1;
          }
          for(var i=0;i<second.length;i++){
            if((second[i]>='0' && second[i]<='9') || (second[i]>='A' && second[i]<='Z') || (second[i]>='a' && second[i]<='z')){
              continue;
            }
            document.getElementById("email").style.backgroundColor = "Red";
            invalid = 1;
          }
        }
      }
      else{
        document.getElementById("email").style.backgroundColor = "Red";
        invalid = 1;
      }
    }
  }
  if(document.getElementById("zip").value == ""){
    document.getElementById("zip").style.backgroundColor = "Red";
    invalid = 1;
  }
  else{
    let zip = document.getElementById("zip").value;
    if(!(parseInt(zip)>0 && zip.length>=5)){
      document.getElementById("zip").style.backgroundColor = "Red";
      invalid = 1;
    }
  }
  if(document.getElementById("email2").value == ""){
    document.getElementById("email2").style.backgroundColor = "Red";
    invalid = 1;
  }
  if(document.getElementById("tel").value == ""){
    document.getElementById("tel").style.backgroundColor = "Red";
    invalid = 1;
  }
  else{
    let tel = document.getElementById("tel").value;
    if(!(parseInt(tel)>0 && tel.length>=8)){
      document.getElementById("tel").style.backgroundColor = "Red";
      invalid = 1;
    }
  }
  if(document.getElementById("dept").value == ""){
    document.getElementById("dept").style.backgroundColor = "Red";
    invalid = 1;
  }
  if(document.getElementById("birth").value == ""){
    document.getElementById("birth").style.backgroundColor = "Red";
    invalid = 1;
  }
  else{
    let birth = document.getElementById("birth").value;
    let year = birth.split('-')[0];
    let month = birth.split('-')[1];
    let day = birth.split('-')[2];
    if(!(parseInt(year)>=0 && year.length==4 && parseInt(month)>=0 && month.length==2 && parseInt(day)>=0 && day.length==2)){
      document.getElementById("birth").style.backgroundColor = "Red";
      invalid = 1;
    }
  }
  let pw = document.getElementById("pw").value;
  let pw2 = document.getElementById("pw2").value;
  if(pw == ""){
    document.getElementById("pw").style.backgroundColor = "Red";
    invalid = 1;
  }
  if(pw2 == ""){
    document.getElementById("pw2").style.backgroundColor = "Red";
    invalid = 1;
  }
  if(!(pw==pw2 && pw.length>=6)){
    document.getElementById("pw").style.backgroundColor = "Red";
    document.getElementById("pw2").style.backgroundColor = "Red";
    invalid = 1;
  }
  if(document.getElementById("ta").value == ""){
    document.getElementById("ta").style.backgroundColor = "Red";
    invalid = 1;
  }
  if(invalid==0){
    alert("Congratulations! You registered the Web Programming Course");
  }
}
