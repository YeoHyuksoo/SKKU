function add(){
  if(document.getElementById("monsters").checked==true){
    var parent = document.getElementById("people");
    var newp = document.createElement("div");
    newp.setAttribute("class", "person monster");
    parent.appendChild(newp);
  }
  else{
    var parent = document.getElementById("people");
    var newp = document.createElement("div");
    newp.setAttribute("class", "person evil");
    parent.appendChild(newp);
  }
}

function kill(){
  if(document.getElementById("monsters").checked==true){
    var parent = document.getElementById("people");
    var children = parent.children;
    for(var i=0;i<children.length;i++){
      if(children[i].className == "person monster"){
        if(getRandomInt(0, 2)==0){
          children[i].setAttribute("class", "person splat");
        }
      }
    }
  }
  else{
    var parent = document.getElementById("people");
    var children = parent.children;
    for(var i=0;i<children.length;i++){
      if(children[i].className == "person evil"){
        if(getRandomInt(0, 2)==0){
          children[i].setAttribute("class", "person splat");
        }
      }
    }
  }
}

function cleanup(){
  var parent = document.getElementById("people");
  var children = parent.children;
  for(var i=0;i<children.length;i++){
    if(children[i].className=="person splat"){
      parent.removeChild(children[i]);
      i--;
    }
  }
}

function stomp(){
  var parent = document.getElementById("people");
  var children = parent.children;
  for(var i=0;i<children.length;i++){
    if(getRandomInt(0, 3)==0){
      children[i].setAttribute("class", "person splat");
    }
  }
}

function enrage(){
  var img = document.getElementById("supersaipien");
  if(img.src.indexOf("supersaipien1")!=-1){
    img.src="./images/supersaipien2.png";
  }
  else{
    img.src="./images/supersaipien1.png";
  }
}

function patrol(){
  var target = document.getElementById("supersaipien");
  var vx = 4;
  move();
  function move(){
    var x = parseInt(target.style.left, 10);
    x += vx;
    target.style.left = x + 'px';
    if(x + 50 > 1300){
      x = 1250;
      vx *= -1;
    }
    if(x < 885){
      x = 885;
      vx *= 0;
      stop();
    }
    animate = setTimeout(function(){move();}, 20);
  }
  function stop(){
    clearTimeout(animate);
  }
}

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min;
}
