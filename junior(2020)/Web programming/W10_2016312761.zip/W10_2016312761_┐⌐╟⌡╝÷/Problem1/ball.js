"use strict";
(function() {
  window.onload = function() {
    var ball = document.getElementById("ball");
    var gravity = 1;
    var bounce = 0.75;
    var y = 0;
    var vy = 5;
    setInterval(move, 20);
    function move(){
      y += vy;
      ball.style.top = y + 'px';

      vy+=gravity;

      if(y + 20 > 370){
        y = 355;
        vy *= -bounce;
      }
    }
  }

})();
