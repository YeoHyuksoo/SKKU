#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]){
	if(argc!=2 || argv[1][0]=='-'){
		exit();
	}
	int pnum=atoi(argv[1]);
	ps(pnum);
	exit();
}

