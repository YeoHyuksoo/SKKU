#include "types.h"
#include "stat.h"
#include "user.h"

int main(){
	int res;
	res = munmap(1);
	printf(1, "%d", res);
}
