#include "types.h"
#include "user.h"
#include "param.h"
#include "fcntl.h"

int main(int argc, char** argv) {
	int i;
	int size = 8192;
	int fd = open("README", O_RDWR);
	uint res1 = mmap(0, size, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_POPULATE, fd, 0);
	int pid = fork();
	if(pid==0){
		char* text = (char*) res1;
		for(i=0;i<64;i++){
			text[i]='a';
		}
		munmap(res1);
		printf(1, "munmap res1 finish\n");
	}
	else{
		wait();
		uint res2 = mmap(8192, size, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_POPULATE, fd, 4096);
		char* text2 = (char*) res2;
		for(i=4096;i<4200;i++){
			printf(1, "%c", text2[i]);
		}
		printf(1, "\n");
		munmap(res2);
		printf(1, "munmap res2 finish\n");
	}

	close(fd);

	exit();
}
