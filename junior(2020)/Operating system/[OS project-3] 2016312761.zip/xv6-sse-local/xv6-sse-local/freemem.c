#include "types.h"
#include "stat.h"
#include "user.h"

int main(){
	int res;
	res = freemem();
	printf(1, "%d", res);
	return 0;
}
