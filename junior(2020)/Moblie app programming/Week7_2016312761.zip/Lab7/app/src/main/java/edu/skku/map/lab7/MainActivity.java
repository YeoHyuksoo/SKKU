package edu.skku.map.lab7;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    /*TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.textView);

        View view = findViewById(R.id.view);
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                float curX = event.getX();
                float curY=event.getY();

                if(action==event.ACTION_DOWN){
                    println("Touch event occur : "+curX+", "+curY);
                }else if(action==event.ACTION_MOVE){
                    println("finger move : "+curX+", "+curY);
                }else if(action==event.ACTION_UP){
                    textView.setText("");
                    println("Touch event end : "+curX+", "+curY);
                }
                return true;
            }
        });
    }
    public void println(String data){
        textView.append(data+"\n");
    }*/
    TextView textView;
    GestureDetector detector;
    String name_content;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        View view = findViewById(R.id.view);
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                float curX = event.getX();
                float curY=event.getY();

                if(action==event.ACTION_DOWN){
                    println("Touch event occur : "+curX+", "+curY);
                }else if(action==event.ACTION_MOVE){
                    println("finger move : "+curX+", "+curY);
                }else if(action==event.ACTION_UP){
                    textView.setText("");
                    println("Touch event end : "+curX+", "+curY);
                }
                return true;
            }
        });
        detector = new GestureDetector(this, new GestureDetector.OnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                println("onDown event occur.");
                return true;
            }

            @Override
            public void onShowPress(MotionEvent e) {
                println("onShowPress event occur.");
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                println("onSingleTapUp event occur.");
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                println("onScroll event occur : " + distanceX + ", " + distanceY);
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                println("onLongPress event occur.");
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                println("onFling event occur: " + velocityX + ", " + velocityY);
                return true;
            }
        });
        View view2 = findViewById(R.id.view2);
        view2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                detector.onTouchEvent(motionEvent);
                return true;
            }
        });
        if(savedInstanceState != null){
            name_content = savedInstanceState.getString("name_content");
            textView.setText(name_content);
        }
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        name_content = textView.getText().toString();
        outState.putString("name_content",name_content);

    }
    public void println(String data){
        textView.append(data+"\n");
    }
    /*TextView textView;
    EditText editText;
    Button button;
    String name_content;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.editText);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText(editText.getText().toString());
            }
        });
        if(savedInstanceState != null){
            name_content = savedInstanceState.getString("name_content");
            textView.setText(name_content);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        name_content = textView.getText().toString();
        outState.putString("name_content",name_content);

    }*/
}

