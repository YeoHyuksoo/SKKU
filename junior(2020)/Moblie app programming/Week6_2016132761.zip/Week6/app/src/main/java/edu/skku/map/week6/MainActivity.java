package edu.skku.map.week6;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textView = (TextView)findViewById(R.id.result);
        final Context context = this;
        AsyncTask<Integer, Double, String> asyncTask = new AsyncTask<Integer, Double, String>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                Toast.makeText(context,"Start AsyncTask", Toast.LENGTH_SHORT).show();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                Toast.makeText(context,"End AsyncTask", Toast.LENGTH_SHORT).show();
            }

            @Override
            protected void onProgressUpdate(Double... values) {
                super.onProgressUpdate(values);
                textView.setText("ㅠ = "+values[0]);
            }

            @Override
            protected String doInBackground(Integer... integers) {
                double hit=0.0, total=0.0;
                for(int i=1;i<integers[0];i++){
                    if(total!=0 && Math.abs((hit/total)*4-Math.PI)<0.000001){
                        break;
                    }
                    try{
                        Thread.sleep(100);
                        double x=Math.random();
                        double y=Math.random();
                        if(x*x+y*y<=1.0){
                            hit++;
                        }
                        total++;
                        publishProgress(hit/total*4);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                }
                return null;
            }
        };
        asyncTask.execute(10000);
    }
}
