package edu.skku.map.week8;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    Button button, button2;
    EditText editText;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        textView2 = findViewById(R.id.response);
        button = findViewById(R.id.sendGET);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OkHttpClient client = new OkHttpClient();
                HttpUrl.Builder urlBuilder = HttpUrl.parse("http://www.omdbapi.com").newBuilder();
                urlBuilder.addQueryParameter("t", editText.getText().toString());
                urlBuilder.addQueryParameter("apikey", "a07474cb");
                String url = urlBuilder.build().toString();

                Request req = new Request.Builder().url(url).build();
                client.newCall(req).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        final String getResponse = response.body().string();
                        Gson gson = new GsonBuilder().create();
                        final DataModel data = gson.fromJson(getResponse, DataModel.class);

                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textView2.setText("");
                                String str = data.getTitle();
                                textView2.append("Title: "+str);
                                str = data.getYear();
                                textView2.append("\nYear: "+str);
                                str = data.getReleased();
                                textView2.append("\nReleased: "+str);
                                str = data.getRuntime();
                                textView2.append("\nRuntime: "+str);
                                str = data.getDirector();
                                textView2.append("\nDirector: "+str);
                                str = data.getGenre();
                                textView2.append("\nGenre: "+str);
                                str = data.getImdbRating();
                                textView2.append("\nImdbRating: "+str);
                                str = data.getMetascore();
                                textView2.append("\nMetascore: "+str);
                            }
                        });
                    }
                });

            }
        });
    }
}
