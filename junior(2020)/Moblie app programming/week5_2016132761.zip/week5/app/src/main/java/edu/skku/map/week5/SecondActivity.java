package edu.skku.map.week5;

import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        String nameText = intent.getStringExtra("myData");
        final String wordText = intent.getStringExtra("myData2");
        TextView textview = findViewById(R.id.nametext);
        textview.setText("Hi, "+ nameText);

        Button btn = findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            public void searchWeb(String query){
                Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                intent.putExtra(SearchManager.QUERY, query);
                if(intent.resolveActivity(getPackageManager())!= null)
                    startActivity(intent);
            }
            @Override
            public void onClick(View v) {
                searchWeb(wordText);
            }
        });

    }
}
