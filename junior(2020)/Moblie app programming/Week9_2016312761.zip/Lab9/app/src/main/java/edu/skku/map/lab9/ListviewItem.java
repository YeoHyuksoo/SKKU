package edu.skku.map.lab9;

public class ListviewItem {
    private String titlestr;
    private String ownerstr;
    private String contentstr;

    public void setTitle(String title) {
        titlestr = title;
    }
    public void setOwner(String owner) {
        ownerstr = owner;
    }
    public void setContent(String content) {
        contentstr = content;
    }

    public String getTitle() {
        return this.titlestr;
    }
    public String getOwner() {
        return this.ownerstr;
    }
    public String getContent() {
        return this.contentstr;
    }
}
