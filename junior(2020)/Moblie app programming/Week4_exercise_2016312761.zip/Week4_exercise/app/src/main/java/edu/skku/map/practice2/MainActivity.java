package edu.skku.map.practice2;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ListView list1=(ListView)findViewById(R.id.listView);
        ArrayList<Integer> data1 = new ArrayList<Integer>();
        ArrayList<Integer> data2 = new ArrayList<Integer>();
        ArrayList<String> data3 = new ArrayList<String>();
        final TextView tv1=(TextView)findViewById(R.id.textView);
        data1.add(0);
        for(int i=1;i<=10;i++){
            data1.add(i);
            data2.add((int)Math.pow(2, i));
        }
        data3.add("2016312761");
        data3.add("Yeo Hyuksoo");
        data3.add("Department of Software");
        data3.add("College of Software");
        data3.add("SungKyunKwan Univ.");
        final ArrayAdapter<Integer> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data1);
        final ArrayAdapter<Integer> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data2);
        final ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data3);

        Button btn1= (Button)findViewById(R.id.button);
        Button btn2= (Button)findViewById(R.id.button2);
        Button btn3= (Button)findViewById(R.id.button3);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv1.setText("FIRST");
                list1.setAdapter(adapter1);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv1.setText("SECOND");
                list1.setAdapter(adapter2);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv1.setText("THIRD");
                list1.setAdapter(adapter3);
            }
        });
    }
}
